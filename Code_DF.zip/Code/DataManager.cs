using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DataManager : MonoBehaviour
{
    public GameObject canvas;

    private void Awake()
    {
        DontDestroyOnLoad(canvas); // dont destroy canvas for highscore
        SceneManager.LoadScene("Menu");
    }
}