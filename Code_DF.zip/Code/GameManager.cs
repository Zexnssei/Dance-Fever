using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public AudioSource theMusic;

    public bool startPlaying; // bool to start game
    public bool musicStarted; // bool to start music (two bools reduntant but good for organization and further building potential)
    public float songLength = 62f; // second length of song track (default 62)
    
    public int currentScore;
    public int scorePerNote = 100;

    public Text scoreText;
    public Canvas canvas;

    public BeatScroller theBS;

    public static GameManager instance; // gm Object;

    // Start is called before the first frame update
    void Start()
    {
        canvas = GameObject.FindGameObjectWithTag("gameplayCanvas").GetComponent<Canvas>();
        scoreText = GameObject.FindGameObjectWithTag("scoreTxt").GetComponent<Text>();
        instance = this; // set game object to the current instance
        startPlaying = false; // startPlaying default to false
        musicStarted = false; // musicStarted should default to false
        scoreText.text = "Score: 0"; // set default score
    }

    // Update is called once per frame
    void Update()
    {
        if (musicStarted) // countdown if song has started
        {
            songLength -= Time.deltaTime; // countDown songLength var
        }
        
        //check for input
        // todo change to arrow keys only
        if(Input.GetKeyDown(KeyCode.D)  || Input.GetKeyDown(KeyCode.F)  || Input.GetKeyDown(KeyCode.J) || Input.GetKeyDown(KeyCode.K))
        {
            if (!musicStarted)
            {
                theMusic.Play();
            }
            startPlaying = true;
            musicStarted = true;
        }
        
        // end game if song is finished
        if (songLength <= 0)
        {
            scoreText.text = "Recent Score: " + currentScore;
            SceneManager.LoadScene("Menu");
        }
    }

    public void NoteHit()
    {
        currentScore += scorePerNote;
        scoreText.text = "Score: " + currentScore;

        Debug.Log("Hit On Time");
    }

    public void NoteMissed()
    {
        Debug.Log("Missed Note");
    }
}